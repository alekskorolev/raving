var config = {};

config.core = {
	protocol: 'http',
	host: 'localhost',
	port: 8809,
	path: '',
	sessionkey: 'kdfshgasudfoajsfod8vf76gyo82bu3yfv',
	db: {
		host: 'localhost',
		db: 'raving'
	},
	mode: 'development',
	smtp: {
		username: 'serpteam_test', 
		password: '1qaz@WSX3edc', 
		host: 'smtp.sendgrid.net', 
		ssl: true, 
		from: 'dev@serpteam.ru'
	},
	appid: 'raving',
	theme: 'default'
};

config.build = {
	src: 'source/'+config.core.theme+'/', 
	dst: 'www/'
};

config.modules = {};

<<<modulescongif>>>

module.exports = config;