var gulp = require('gulp');
var less = require('gulp-less');
/*var ngmin = require('gulp-ngmin');*/
var path = require('path');
var browserify = require('gulp-browserify');
var concat = require('gulp-concat');
var angularTemplates = require('gulp-angular-templates');
/*var ngAnnotate = require('gulp-ng-annotate');*/
var log4js = require('log4js');
var webserver = require('gulp-webserver');
var nodemon = require('gulp-nodemon');
/*var uglify = require('gulp-uglify');*/
/*var minhtml = require('gulp-minify-html');*/
var config = require('./config');
var src = config.src;
var dst = config.dst;
var srv = config.srv;


var log = log4js.getLogger();
log.setLevel('info');

// Basic usage
log.debug(config);


gulp.task('admin', function() {
  // Single entry point to browserify
  var brsf = browserify({
      insertGlobals : true,
      debug : true
    });
  brsf.on('error',function(e){
      log.error(e);
      brsf.end();
    });
  gulp.src(src.js+'admin.js')
    .pipe(brsf)		
		//.pipe(ngmin())
		//.pipe(ngAnnotate())
/*		.pipe(uglify({
			sequences     : true,  // join consecutive statemets with the “comma operator”
			properties    : true,  // optimize property access: a["foo"] → a.foo
			dead_code     : true,  // discard unreachable code
			drop_debugger : true,  // discard “debugger” statements
			unsafe        : false, // some unsafe optimizations (see below)
			conditionals  : true,  // optimize if-s and conditional expressions
			comparisons   : true,  // optimize comparisons
			evaluate      : true,  // evaluate constant expressions
			booleans      : true,  // optimize boolean expressions
			loops         : true,  // optimize loops
			unused        : true,  // drop unused variables/functions
			//hoist_funs    : true,  // hoist function declarations
			//hoist_vars    : false, // hoist variable declarations
			if_return     : true,  // optimize if-s followed by return/continue
			join_vars     : true,  // join var declarations
			cascade       : true,  // try to cascade `right` into `left` in sequences
			side_effects  : true,  // drop side-effect-free statements
			warnings      : true,  // warn about potentially dangerous optimizations/code
			global_defs   : {} }))*/
    .pipe(gulp.dest(dst.js+'../admin/js'))
});

gulp.task('adminhtml', function () {

  var atml = angularTemplates({module: config.www.constants.appid/*, withBrowserify: true*/});
  atml.on('error',function(e){
      log.error(e);
      atml.end();
    });
  gulp.src('source/themes/admin/html/**/*.html')
/*    .pipe(minhtml())*/
		.pipe(atml)
		.pipe(concat('admintemplates.js'))
    .pipe(gulp.dest(src.js));
});

gulp.task('adminless', function () {
    var lss = less({
        paths: [ path.join(__dirname, 'less', 'includes') ]
      });
    lss.on('error',function(e){
      log.error(e);
      lss.end();
    });
    gulp.src('source/themes/admin/less/style.less')
      .pipe(lss)
      .pipe(gulp.dest(dst.css+'../admin/css'));
})


gulp.task('scripts', function() {
  // Single entry point to browserify
  var brsf = browserify({
      insertGlobals : true,
      debug : true
    });
  brsf.on('error',function(e){
      log.error(e);
      brsf.end();
    });
  gulp.src(src.js+'index.js')
    .pipe(brsf)
		//.pipe(ngmin())
		//.pipe(ngAnnotate())
/*		.pipe(uglify({
			sequences     : true,  // join consecutive statemets with the “comma operator”
			properties    : true,  // optimize property access: a["foo"] → a.foo
			dead_code     : true,  // discard unreachable code
			drop_debugger : true,  // discard “debugger” statements
			unsafe        : false, // some unsafe optimizations (see below)
			conditionals  : true,  // optimize if-s and conditional expressions
			comparisons   : true,  // optimize comparisons
			evaluate      : true,  // evaluate constant expressions
			booleans      : true,  // optimize boolean expressions
			loops         : true,  // optimize loops
			unused        : true,  // drop unused variables/functions
			//hoist_funs    : true,  // hoist function declarations
			//hoist_vars    : false, // hoist variable declarations
			if_return     : true,  // optimize if-s followed by return/continue
			join_vars     : true,  // join var declarations
			cascade       : true,  // try to cascade `right` into `left` in sequences
			side_effects  : true,  // drop side-effect-free statements
			warnings      : true,  // warn about potentially dangerous optimizations/code
			global_defs   : {} }))*/
    .pipe(gulp.dest(dst.js))
});

gulp.task('html', function () {
  var atml = angularTemplates({module: config.www.constants.appid/*, withBrowserify: true*/});
  atml.on('error',function(e){
      log.error(e);
      atml.end();
    });
  gulp.src('source/themes/' + src.theme + '/html/**/*.html')
/*		.pipe(minhtml())*/
    .pipe(atml)
		.pipe(concat('templates.js'))
    .pipe(gulp.dest(src.js));
});

gulp.task('www', function () {
	gulp.src(srv.root)
		.pipe(webserver(srv.options));
});

gulp.task('less', function () {
    var lss = less({
        paths: [ path.join(__dirname, 'less', 'includes') ]
      });
    lss.on('error',function(e){
      log.error(e);
      lss.end();
    });
    gulp.src('source/themes/' + src.theme + '/less/style.less')
      .pipe(lss)
      .pipe(gulp.dest(dst.css));
})

gulp.task('serve', function (cb) {
    nodemon({
        script  : './server/app.js',
        watch   : 'server/**/*.*'
        //...add nodeArgs: ['--debug=5858'] to debug
        //..or nodeArgs: ['--debug-brk=5858'] to debug at server start
    });
});

gulp.task('migrate', function (cb) {
    nodemon({
        script  : './server/migrate.js'
        //...add nodeArgs: ['--debug=5858'] to debug
        //..or nodeArgs: ['--debug-brk=5858'] to debug at server start
    });
});

var watchdirs_js = [
	src.js+'*.js', 
	src.js + "**/*.js",
	'./node_modules/**/*.js',
	'./modules.js',
	'./gulpfile.js',
	'./source/js/admintemplates.js',
	'./source/js/templates.js',
	'config.js'
]

var watchdirs_html = [
	'source/themes/' + src.theme + '/html/**/*.html', 
	'source/themes/' + src.theme + '/html/*.html',
	'source/themes/admin/html/*.html',
	'source/themes/admin/html/**/*.html'
]

var watchdirs_less = [
	'source/themes/' + src.theme + '/less/**/*.less', 
	'source/themes/' + src.theme + '/less/*.less',
	'source/themes/admin/less/*.less',
	'source/themes/admin/less/**/*.less'
]
// Действия по умолчанию
gulp.task('default', function(){
	
  gulp.run('html', 'adminhtml', 'less', 'adminless', 'scripts', 'admin', 'serve'  );

  gulp.watch([watchdirs_js], function(event){
    gulp.run('scripts');
		gulp.run('admin');
  });
  gulp.watch(watchdirs_html, function(event){
    gulp.run('html');
		gulp.run('adminhtml');
  });
  gulp.watch(watchdirs_less, function(event){
    gulp.run('less');
		gulp.run('adminless');
  });
});

gulp.task('build', function () {
	gulp.run('html', 'adminhtml', 'less', 'adminless', 'scripts-build', 'admin-build' );
});

